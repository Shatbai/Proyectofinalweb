

describe('getting to home page', () => {
  it('test1 pagina inicial abierta', () => {
    cy.visit('http://localhost:3000')
    cy.contains("nueva frase")
  })

  it('test2 link a modificacion de frase', () => {
    cy.visit('http://localhost:3000')
    cy.contains("Enviar").click()
  })
  
  it('test3 frase modificada', () => {
    cy.visit('http://localhost:3000')
    cy.get('input[id').type("dios")
    cy.contains("Enviar").click()
    cy.contains("dios")
  })

  it('test4 llega al dominio publico', () => {
    cy.request('http://proyectofinalweb.live/')
    
    
  })

})